name = 'Arnold '
if name > 'Arnold':
  print('After Arnold')
elif name < 'Arnold':
  print('Before Arnold')
else:
  print('Is Arnold')