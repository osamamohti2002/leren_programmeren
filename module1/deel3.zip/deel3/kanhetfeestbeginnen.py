gastheer = 0
gasten = 1
drank = 1
chips = 1

if (gasten and chips and drank) or (gastheer and drank) or gastheer or gasten:
    print('Start the Party')
else:

    print('No Party')
















# gastheer =1
# gasten = 0
# drank = 0
# chips = 0
# # print((gasten and chips and drank) or (gastheer > "" and drank))
# if ((gasten and chips and drank) or (gastheer and drank)):
#     print('Start the Party')
# else:
#     print('geen feest')