import random

# Functie om de score op te tellen
def update_score(points):
    global score
    score += points

# Functie om een willekeurige keuze te maken
def make_choice(options):
    print("Mogelijke keuzes:")
    for i, option in enumerate(options):
        print(f"{i + 1}: {option}")
    choice = input("Maak je keuze (1-" + str(len(options)) + "): ")
    return int(choice) - 1

print("Welkom bij Het Mysterie van de Verloren Schat!")

print("Je bevindt je aan de rand van een dichtbegroeide jungle.")
print("Je hebt een oude kaart en enkele aanwijzingen om je te leiden naar de verloren schat.")

# Begin van het spel
score = 0

# Uitdaging 1
print("Je moet de jungle in trekken. Welke richting kies je?")
choice = make_choice(["Het linkerpad volgen", "Het rechterpad volgen"])
if choice == 0:
    print("Goed gekozen! Het linkerpad lijkt veelbelovend.")
    update_score(10)
else:
    print("Helaas, het rechterpad was een doodlopende weg.")
    update_score(-5)

# Uitdaging 2
print("Je komt bij een wilde rivier. Ga je proberen over te steken (P) of een omweg maken (O)?")
choice = input("P / O: ")
if choice.lower() == "p":
    success = random.choice([True, False])
    if success:
        print("Je bent veilig aan de overkant gekomen.")
        update_score(15)
    else:
        print("Je bent in de sterke stroming beland en verliest wat kostbaar bezit.")
        update_score(-10)
else:
    print("Je maakt een omweg om de rivier en komt veilig aan de overkant.")
    update_score(5)

# Einde van het spel
print("Gefeliciteerd! Je hebt de verloren schat gevonden.")
print(f"Je totale score is {score} punten.")





