def round_piece(amount: float) -> int:
  return math.ceil(amount)


def round_quarter(amount: float) -> float:
    if amount > 10:
        return round_piece(amount)
    else:
        remainder = amount % 0.25
        if remainder <= 0.125:
            return amount - remainder
        else:
            return amount + (0.25 - remainder)

    return vershil1

print(round_quarter(1.625))